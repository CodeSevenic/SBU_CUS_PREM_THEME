<?php

/*
Plugin Name:    sbu_theme metaboxes
Plugin URL:     
Description:    Adding Metaboxes for sbu_theme
Version:        1.0.0
Author:         Sibusiso Shongwe
Author URL:     https://codesevenic-portfolio.web.app
License:        GPL2
License URI:    https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:    sbu_theme-metaboxes
Domain Path:    /language
 */

if (!defined('WPINC')) {
  die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');