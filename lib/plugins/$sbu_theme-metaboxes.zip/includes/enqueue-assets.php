<?php

function metaboxes_admin_assets()
{
  global $pagenow;
  if ($pagenow !== 'post.php') return;
  wp_enqueue_script('metaboxes-admin-scripts', plugins_url('sbu_theme-metaboxes/dist/assets/js/admin.js'), array('jquery'), '1.0.0', true);

  wp_enqueue_style('metaboxes-admin-stylesheet', plugins_url('sbu_theme-metaboxes/dist/assets/css/admin.css'), array(), '1.0.0', 'all');
}

add_action('admin_enqueue_scripts', 'metaboxes_admin_assets');